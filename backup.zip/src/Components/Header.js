import React from 'react'

import '../CSS/Header.css'
// import { Link } from 'react-router-dom'

export default function Header(props) {
  return (
    <div>
        <div className='header1'>
        {/* <Link to="/"><img className='logo' src={logo} alt='logo' onClick={props.click}/></Link>
            <img className='icon1' src={bell} alt='icon1' onClick={props.click}/>
            <img className='icon2' src={user} alt='icon2' onClick={props.click}/> */}
        </div>
    </div>
  )
}
