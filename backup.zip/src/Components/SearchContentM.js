import React from "react";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";

import Select from "@mui/material/Select";
import { Box, InputLabel, TextField } from "@mui/material";

export default function SearchContentM(props) {
  return (
    // <div
    //   sx={{ display: "flex", justifyContent: "center", alignItems: "center" }}
    // >
      <>
      </>
    // </div>
  );
}
