import { Box } from '@mui/material'
import React from 'react'

export default function AddMajkur() {
  return (
    <Box sx={{mt:'-1.5%',typography: 'body1'}}>
      <p style={{color:'#4F62B0'}} >+ नवीन मजकूर </p>
    </Box>
  )
}
