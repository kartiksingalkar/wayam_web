import React from "react";

import { Box, OutlinedInput } from "@mui/material";

import InputAdornment from "@mui/material/InputAdornment";
import DriveFolderUploadIcon from "@mui/icons-material/DriveFolderUpload";

export default function ContentInside(props) {
  return (
    <></>
  );
}
